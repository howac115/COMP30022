import React from 'react';

import './Toolbar.css';
import Info from '../Info/Info';

const toolbar = props => (
  <header className="toolbar">
    <nav className="toolbar_navigation">
      <div></div>
      <div className="toolbar_Logo"><a href="/">E-profilio</a></div>
      <div className="spacer" />
      <div className="items">
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/">About me</a></li>
          <li><a href="/">Achievement</a></li>
          <li><a href="/">Experience</a></li>
          <li><a href="/">Contact me</a></li>
        </ul>
      </div>

    </nav>

    <div id="showcase">
      <div class="container">

        <div class="showcase-content">
          <h1><span class="text-primary">Nice</span> to meet you</h1>
          <p class="lead">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolor, eligendi laboriosam. Repellendus officia harum eaque.</p>
          <a class="btn" >About me</a>
        </div>
      </div>
    </div>

    <div>
      <Info />
    </div>

  </header >



);

export default toolbar;