import React from 'react';

import './Info.css';

const info = props => (


  <section id="home-info" class="bg-dark">
    <div class="info-img"></div>
    <div class="info-content">
      <h2><span class="text-primary">The Summary</span> Of Myself</h2>
      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Assumenda
        aliquam dolor alias iste autem, quaerat magni unde accusantium qui
        fuga placeat quidem quo pariatur, voluptatum, ea sequi? Corporis,
        explicabo quisquam dolor placeat praesentium nesciunt mollitia quos
        nobis natus voluptatum asperiores!
      </p>
      <a class="btn btn-light">Read More</a>
    </div>
  </section>

);

export default info;